Parser.java means the first exercise and Parser2.java means the second exercies.

Use javac to compile java files and use java to run.

**eg**

```
javac Parser.java
java Parser "a+(a*a)"
```

